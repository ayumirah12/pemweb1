<?php $__env->startSection('judul', 'Galeri'); ?>

<?php $__env->startSection('konten'); ?>
<div class="lebar halaman">
    <div class="panel kotak">
        <h1>Galeri Foto</h1>
        <p class="lead">Klik foto untuk memperbesar dan melihatnya lebih dekat.</p>
    </div>

    
    <nav class="album-nav" aria-label="Pilih album">
        <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#<?php echo e($a['id']); ?>"><?php echo e($a['judul']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    
    <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="panel album <?php echo e($a['id']); ?>" id="<?php echo e($a['id']); ?>">
            <h2><?php echo e($a['judul']); ?></h2>
            <p class="ket"><?php echo e($a['ket']); ?> (<?php echo e(count($a['foto'])); ?> foto)</p>

            <div class="galeri-grid">
                <?php $__currentLoopData = $a['foto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure>
                        <button type="button" class="galeri-item"
                                data-src="<?php echo e(asset('images/galeri/' . $f['file'])); ?>"
                                data-judul="<?php echo e($f['judul']); ?>"
                                data-album="<?php echo e($a['id']); ?>"
                                data-album-judul="<?php echo e($a['judul']); ?>"
                                aria-label="Perbesar foto: <?php echo e($f['judul']); ?>">
                            <img src="<?php echo e(asset('images/galeri/' . $f['file'])); ?>" alt="<?php echo e($f['judul']); ?>" loading="lazy">
                            <span class="cap"><?php echo e($f['judul']); ?></span>
                        </button>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="lightbox" id="lightbox" role="dialog" aria-modal="true" aria-label="Penampil foto" hidden>
    <div class="lb-bar">
        <p class="lb-cap" aria-live="polite"></p>
        <div class="lb-alat">
            <button type="button" class="lb-min" aria-label="Perkecil">&minus;</button>
            <button type="button" class="lb-plus" aria-label="Perbesar">+</button>
            <button type="button" class="lb-reset">Reset</button>
            <button type="button" class="lb-tutup" aria-label="Tutup">&times;</button>
        </div>
    </div>
    <div class="lb-stage">
        <button type="button" class="lb-nav lb-prev" aria-label="Foto sebelumnya">&lsaquo;</button>
        <img class="lb-img" alt="" draggable="false">
        <button type="button" class="lb-nav lb-next" aria-label="Foto berikutnya">&rsaquo;</button>
    </div>
    <p class="lb-petunjuk">Klik foto atau tombol + dan &minus; untuk zoom. Geser foto saat diperbesar. Panah kiri dan kanan pindah foto, Esc menutup.</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('skrip'); ?>
    <script src="<?php echo e(asset('js/galeri.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\website-saya\resources\views/galeri.blade.php ENDPATH**/ ?>
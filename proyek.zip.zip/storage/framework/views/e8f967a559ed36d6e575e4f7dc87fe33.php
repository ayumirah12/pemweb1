<?php $__env->startSection('judul', 'Data Diri'); ?>

<?php $__env->startSection('konten'); ?>
<div class="lebar halaman">
    <div class="panel kotak">
        <h1>Data Diri</h1>
        <p class="lead">Data diri saya ditampilkan dengan looping while.</p>

        <?php
            $i = 0; // nomor awal
        ?>

        <table class="tabel">
            <tbody>
                <?php while($i < count($dataDiri)): ?>
                    <tr>
                        <th><?php echo e($dataDiri[$i]['label']); ?></th>
                        <td>
                            <?php if(!empty($dataDiri[$i]['link'])): ?>
                                <a href="<?php echo e($dataDiri[$i]['link']); ?>" target="_blank" rel="noopener"><?php echo e($dataDiri[$i]['isi']); ?></a>
                            <?php else: ?>
                                <?php echo e($dataDiri[$i]['isi']); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php
                        $i++; // naikkan nomor, kalau tidak looping tidak akan berhenti
                    ?>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <h2 class="judul-bagian">Hobi</h2>
    <div class="hobi-grid">
        <?php $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="panel hobi">
                <h3><?php echo e($h['nama']); ?></h3>
                <p><?php echo e($h['isi']); ?></p>
                <div class="hobi-foto">
                    <?php $__currentLoopData = $h['gambar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('images/' . $g['file'])); ?>" alt="<?php echo e($g['judul']); ?>" title="<?php echo e($g['judul']); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['logo' => !empty($g['logo'])]); ?>" loading="lazy">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <h2 class="judul-bagian" id="film">Film &amp; Serial Favorit</h2>
    <div class="hobi-grid">
        <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="panel hobi anggota">
                <h3><?php echo e($f['judul']); ?></h3>
                <p><b><?php echo e($f['jenis']); ?></b> &middot; <?php echo e($f['asal']); ?></p>
                <p><?php echo e($f['genre']); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\website-saya\resources\views/data-diri.blade.php ENDPATH**/ ?>
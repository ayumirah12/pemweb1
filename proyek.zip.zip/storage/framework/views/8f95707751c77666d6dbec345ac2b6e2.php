<?php $__env->startSection('judul', 'Playlist'); ?>

<?php $__env->startSection('konten'); ?>
<div class="lebar halaman">
    <div class="panel kotak">
        <h1>Playlist</h1>
        <p class="lead">Lagu favoritku, langsung dari Spotify. Klik Healing atau Gaming untuk ganti playlist.</p>
    </div>

    <div class="panel layanan" data-tabs>
        <aside class="tab-kiri">
            <h3 class="judul-kecil">Pilih playlist</h3>
            <ul role="tablist" aria-label="Pilih playlist">
                <?php $__currentLoopData = $playlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <button type="button" role="tab" class="tab-btn <?php if($loop->first): ?> aktif <?php endif; ?>"
                                data-tab-target="playlist-<?php echo e($p['id']); ?>"
                                aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                                <?php if(!$loop->first): ?> tabindex="-1" <?php endif; ?>><?php echo e($p['nama']); ?></button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </aside>

        <div class="tab-isi">
            <?php $__currentLoopData = $playlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-tab <?php if($loop->first): ?> masuk <?php endif; ?>" id="playlist-<?php echo e($p['id']); ?>" role="tabpanel" data-tab-panel <?php if(!$loop->first): ?> hidden <?php endif; ?>>
                    <h2><?php echo e($p['nama']); ?></h2>
                    <p class="lead-kecil"><?php echo e($p['ket']); ?></p>

                    <?php if($p['embed']): ?>
                        <iframe class="spotify" src="<?php echo e($p['embed']); ?>" title="<?php echo e($p['judul']); ?>"
                                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                                loading="lazy"></iframe>
                    <?php else: ?>
                        <div class="kosong">
                            <p><strong>Playlist <?php echo e($p['nama']); ?> belum diisi.</strong></p>
                            <ol>
                                <li>Buka Spotify, pilih playlist-mu (harus public).</li>
                                <li>Klik titik tiga, lalu Share, lalu Copy link to playlist.</li>
                                <li>Tempel link-nya di kolom <code>'url'</code> pada <code>daftarPlaylist()</code> di HalamanController.php.</li>
                            </ol>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="catatan">Perlu internet. Kalau belum login Spotify di browser, lagu hanya diputar cuplikan 30 detik.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('skrip'); ?>
    <script src="<?php echo e(asset('js/tab.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\website-saya\resources\views/playlist.blade.php ENDPATH**/ ?>
<?php $__env->startSection('judul', 'Home'); ?>

<?php $__env->startSection('konten'); ?>

<section class="lebar">
    <div class="panel hero">
        <div class="hero-teks">
            <h1><?php echo e($nama); ?></h1>
            <p class="peran"><?php echo e($peran); ?></p>
            <p class="lead"><?php echo e($sapaan); ?></p>
            <p><?php echo e($deskripsi); ?></p>
            <p class="aksi">
                <a class="pil emas" href="<?php echo e(route('data-diri')); ?>">Lihat data diri</a>
                <a class="pil" href="<?php echo e(route('galeri')); ?>">Buka galeri</a>
            </p>
        </div>

        <figure class="bingkai">
            
            <img src="<?php echo e(asset($fotoProfil)); ?>" alt="Foto <?php echo e($nama); ?>">
        </figure>

        <div class="titik" aria-hidden="true"><span></span><span></span><span></span><span class="on"></span></div>
    </div>
</section>


<section class="lebar grid2" id="hobi" data-tabs>
    <aside class="panel samping">
        <h3 class="judul-kecil">Hobi saya</h3>
        <ul class="daftar" role="tablist" aria-label="Pilih hobi">
            <?php $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <button type="button" role="tab" class="tab-btn <?php if($loop->first): ?> aktif <?php endif; ?>"
                            data-tab-target="hobi-<?php echo e($loop->index); ?>"
                            aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                            <?php if(!$loop->first): ?> tabindex="-1" <?php endif; ?>><?php echo e($h['nama']); ?></button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a class="pil emas" href="<?php echo e(route('data-diri')); ?>">Data diri</a>
    </aside>

    <div class="panel utama">
        <h2>Tentang hobi</h2>
        <?php $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel-tab <?php if($loop->first): ?> masuk <?php endif; ?>" id="hobi-<?php echo e($loop->index); ?>" role="tabpanel" data-tab-panel <?php if(!$loop->first): ?> hidden <?php endif; ?>>
                <h3><?php echo e($h['nama']); ?></h3>
                <p><?php echo e($h['isi']); ?></p>
                <div class="hobi-foto">
                    <?php $__currentLoopData = $h['gambar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('images/' . $g['file'])); ?>" alt="<?php echo e($g['judul']); ?>" title="<?php echo e($g['judul']); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['logo' => !empty($g['logo'])]); ?>" loading="lazy">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<div class="lebar meta">
    <span><b>Status:</b> <?php echo e($peran); ?></span>
    <span><b>Instagram:</b> &#64;<?php echo e($instagram); ?></span>
    <a class="pil kecil" href="<?php echo e(route('data-diri')); ?>">selengkapnya</a>
</div>


<section class="lebar">
    <div class="panel layanan" data-tabs>
        <aside class="tab-kiri">
            <h3 class="judul-kecil">Album</h3>
            <ul role="tablist" aria-label="Pilih album">
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <button type="button" role="tab" class="tab-btn <?php if($loop->first): ?> aktif <?php endif; ?>"
                                data-tab-target="album-<?php echo e($loop->index); ?>"
                                aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                                <?php if(!$loop->first): ?> tabindex="-1" <?php endif; ?>><?php echo e($a['judul']); ?></button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </aside>
        <div class="tab-isi">
            <h2>Galeri foto</h2>
            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-tab <?php if($loop->first): ?> masuk <?php endif; ?>" id="album-<?php echo e($loop->index); ?>" role="tabpanel" data-tab-panel <?php if(!$loop->first): ?> hidden <?php endif; ?>>
                    <p class="lead-kecil"><?php echo e($a['ket']); ?></p>
                    <div class="cuplikan">
                        <?php $__currentLoopData = $a['foto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('galeri')); ?>#<?php echo e($a['id']); ?>">
                                <img src="<?php echo e(asset('images/galeri/' . $f['file'])); ?>" alt="<?php echo e($f['judul']); ?>" title="<?php echo e($f['judul']); ?>" loading="lazy">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="pil emas" href="<?php echo e(route('galeri')); ?>#<?php echo e($a['id']); ?>">Buka album <?php echo e($a['judul']); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="lebar" id="film">
    <h2 class="judul-bagian">Film &amp; Serial Favorit</h2>
    <div class="hobi-grid">
        <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="panel hobi anggota">
                <h3><?php echo e($f['judul']); ?></h3>
                <p><b><?php echo e($f['jenis']); ?></b> &middot; <?php echo e($f['asal']); ?></p>
                <p><?php echo e($f['genre']); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('skrip'); ?>
    <script src="<?php echo e(asset('js/tab.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\website-saya\resources\views/home.blade.php ENDPATH**/ ?>
<footer class="footer">
    <div class="lebar footer-isi">
        <div class="footer-merek">
            <span class="logo-nama"><?php echo e($nama); ?></span>
        </div>

        <div class="footer-kolom">
            <h4>Home</h4>
            <a href="<?php echo e(route('home')); ?>">Beranda</a>
            <a href="<?php echo e(route('home')); ?>#hobi">Hobi</a>
        </div>
        <div class="footer-kolom">
            <h4>Profil</h4>
            <a href="<?php echo e(route('data-diri')); ?>">Data Diri</a>
            <a href="<?php echo e(route('galeri')); ?>">Galeri</a>
            <a href="<?php echo e(route('playlist')); ?>">Playlist</a>
            <a href="<?php echo e(route('teman')); ?>">Teman</a>
        </div>
        <div class="footer-kolom">
            <h4>Contact</h4>
            <a href="https://www.instagram.com/<?php echo e($instagram); ?>/" target="_blank" rel="noopener">Instagram &#64;<?php echo e($instagram); ?></a>
        </div>
    </div>
    <p class="lebar hak">&copy; <?php echo e(date('Y')); ?> <?php echo e($nama); ?>. Dibuat dengan Laravel 12.</p>
</footer>
<?php /**PATH C:\xampp\htdocs\website-saya\resources\views/partials/footer.blade.php ENDPATH**/ ?>
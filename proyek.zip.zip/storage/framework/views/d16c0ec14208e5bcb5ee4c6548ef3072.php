<?php $__env->startSection('judul', 'Teman'); ?>

<?php $__env->startSection('konten'); ?>
<div class="lebar halaman">
    <div class="panel kotak">
        <h1>Teman-Temanku</h1>
        <p class="lead">Orang-orang yang bikin hari-hariku lebih seru. Klik nama untuk lihat foto dan playlist masing-masing.</p>
    </div>

    <div class="panel kotak">
        <img src="<?php echo e(asset('images/teman/gendok.jpeg')); ?>" alt="Foto bareng teman-teman" loading="lazy"
             style="display:block;width:100%;max-width:480px;margin:0 auto;border-radius:16px">
    </div>

    <div class="panel layanan" data-tabs>
        <aside class="tab-kiri">
            <h3 class="judul-kecil">Pilih teman</h3>
            <ul role="tablist" aria-label="Pilih teman">
                <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <button type="button" role="tab" class="tab-btn <?php if($loop->first): ?> aktif <?php endif; ?>"
                                data-tab-target="teman-<?php echo e($t['id']); ?>"
                                aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                                <?php if(!$loop->first): ?> tabindex="-1" <?php endif; ?>><?php echo e($t['nama']); ?></button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </aside>

        <div class="tab-isi">
            <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-tab <?php if($loop->first): ?> masuk <?php endif; ?>" id="teman-<?php echo e($t['id']); ?>" role="tabpanel" data-tab-panel <?php if(!$loop->first): ?> hidden <?php endif; ?>>
                    <h2><?php echo e($t['nama']); ?></h2>
                    <p class="lead-kecil"><?php echo e($t['peran']); ?>

                        <?php if(!empty($t['ig'])): ?>
                            &middot; <a href="https://www.instagram.com/<?php echo e($t['ig']); ?>/" target="_blank" rel="noopener">&#64;<?php echo e($t['ig']); ?></a>
                        <?php endif; ?>
                    </p>

                    <div class="hobi-foto">
                        <img class="logo" style="width:180px;height:180px;object-position:center <?php echo e($t['posisi']); ?>" src="<?php echo e(asset('images/' . $t['foto'])); ?>" alt="Foto <?php echo e($t['nama']); ?>" title="<?php echo e($t['nama']); ?>" loading="lazy">
                    </div>

                    <?php if($t['embed']): ?>
                        <iframe class="spotify" src="<?php echo e($t['embed']); ?>" title="Playlist <?php echo e($t['nama']); ?>"
                                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                                loading="lazy"></iframe>
                    <?php else: ?>
                        <div class="kosong">
                            <p><strong>Playlist <?php echo e($t['nama']); ?> belum diisi.</strong></p>
                            <p>Isi link playlist-nya (Spotify / Apple Music / YouTube Music) di kolom <code>'playlist'</code> pada <code>daftarTeman()</code> di HalamanController.php.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('skrip'); ?>
    <script src="<?php echo e(asset('js/tab.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\website-saya\resources\views/teman.blade.php ENDPATH**/ ?>
<?php
    // MENU: tambah/ubah menu di sini. Tiap menu mengarah ke nama route di routes/web.php
    $menu = [
        ['label' => 'Home',      'route' => 'home'],
        ['label' => 'Data Diri', 'route' => 'data-diri'],
        ['label' => 'Galeri',    'route' => 'galeri'],
        ['label' => 'Playlist',  'route' => 'playlist'],
        ['label' => 'Teman',     'route' => 'teman'],
    ];
?>
<header class="header">
    <div class="lebar">
        <a class="logo" href="<?php echo e(route('home')); ?>">
            <span class="logo-nama"><?php echo e($nama); ?></span>
        </a>
        <p class="sambutan"><span aria-hidden="true">&#9664;</span> selamat datang di website <?php echo e($nama); ?> <span aria-hidden="true">&#9654;</span></p>

        <nav class="panel navbar" aria-label="Menu utama">
            <ul class="menu">
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route($m['route'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['aktif' => request()->routeIs($m['route'])]); ?>"><?php echo e($m['label']); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <a class="ig-pil" href="https://www.instagram.com/<?php echo e($instagram); ?>/" target="_blank" rel="noopener">&#64;<?php echo e($instagram); ?></a>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\website-saya\resources\views/partials/header.blade.php ENDPATH**/ ?>